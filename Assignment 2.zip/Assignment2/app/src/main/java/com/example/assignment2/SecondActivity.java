package com.example.assignment2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.example.assignment2.R;

public class SecondActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        TextView text = findViewById(R.id.textView2);
        text.setText("Second Activity :), Making the app usable /n Making the app popular /n Keepng it that way" +
                "");

        Button backBtn = findViewById(R.id.btnBack);
        backBtn.setOnClickListener(v -> startActivity(new Intent(this, com.example.studentinfoapp.MainActivity.class)));
    }
}
